﻿
using IassetTechnicalTest.Controllers;
using System.Net.Http;
//using NUnit.Framework;
using System;
using System.Web.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace IassetTechnicalTest.Tests.Controllers
{
    [TestClass]
    public class WeatherControllerTests
    {

        [TestMethod]
        public void GetCountries_Returns_All_Countries()
        {
            WeatherController controller = new WeatherController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            HttpResponseMessage response = controller.GetCountries();
            string content = response.Content.ToString();
            Assert.IsNotNull(content);
        }

        [TestMethod]
        public void GetCountries_Without_Request_Throws_Exception()
        {
            try
            {
                WeatherController controller = new WeatherController();
                HttpResponseMessage response = controller.GetCountries();
                string content = response.Content.ToString();
                Assert.IsNotNull(content);
            }
            catch (Exception ex)
            {
                Assert.AreEqual(ex.Message, "Object reference not set to an instance of an object.");
            }
        }

        [TestMethod]
        public void GetCities_Returns_Australia_Cities()
        {
            WeatherController controller = new WeatherController();
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            HttpResponseMessage response = controller.GetCitiesByCountryCode("AUS");
            string content = response.Content.ToString();
            Assert.IsNotNull(content);
        }

        [TestMethod]

        public void GetCities_Returns_NO_Cities_Throws_Exception()
        {
            try
            {
                WeatherController controller = new WeatherController();
                controller.Request = new HttpRequestMessage();
                controller.Configuration = new HttpConfiguration();
                HttpResponseMessage response = controller.GetCitiesByCountryCode("NOCity");
                string content = response.Content.ToString();
                Assert.IsNotNull(content);
            }
            catch (Exception ex)
            {
                Assert.AreEqual(ex.Message, "Object reference not set to an instance of an object.");
            }
        }
    }
}
