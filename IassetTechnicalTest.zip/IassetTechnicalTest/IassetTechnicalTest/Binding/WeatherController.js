﻿var app = angular.module('myApp', []);

app.controller('WeatherController', function ($scope, $http) {
    //declaration of variables
    $scope.Countries = [];
    $scope.Cities = [];
    $scope.selectedCity = "";
    $scope.time = new Date();
    $scope.isWeatherDisplay = false;
    $scope.isError = false;


    //call get countries at the time of page load
    $scope.getCountriesData = function () {
        $http.get('api/Countries')
            .then(
            //Success part
            function (response) {
                $scope.Countries = JSON.parse(response.data);
                $scope.$apply();
            },
            //failure part
            function (data, status) {
                $scope.isError = true;
                $scope.errorMessage = "Unable to get the data from the API. Please try after some time";
                $scope.isWeatherDisplay = false;
            }

            );
    };

    $scope.getCountriesData();

    //This is the method to get all cities data based of country
    $scope.getCities = function () {
        $scope.isWeatherDisplay = false;

        if ($scope.selectedCountry !== "") {
            $http.get('api/Cities',
                {
                    params: { code: $scope.selectedCountry },
                }
            ).then
                (
                //Success part
                function (response) {
                    $scope.Cities = JSON.parse(response.data);
                    $scope.$apply();
                },
                //failure part
                function (data, status) {
                    $scope.isError = true;
                    $scope.errorMessage = "Unable to get the data from the API. Please try after some time";
                    $scope.isWeatherDisplay = false;
                }
                )
        }
        else {
            $scope.Cities = [];
        }
    };

    //This is the method to get weather report by the selected location
    $scope.getWeather = function () {
        $scope.isWeatherDisplay = false;
        if ($scope.selectedCity !== "") {
            var strURL = "http://api.openweathermap.org/data/2.5/weather?q=" + $scope.selectedCity + "&appid=8ee69dc69507556267b8f08d4e33f242";
            var post = $http({
                method: "GET",
                url: strURL,
                dataType: 'json',              
                headers: { "Content-Type": "application/json" }
            });
            //Success part
            post.then(function (data, status) {
                $scope.Weather = data.data;
                $scope.isWeatherDisplay = true;
            });
            //failure part
            post.error(function (data, status) {
                getDefaultAPIData();
                $scope.isError = true;
                $scope.errorMessage = "Unable to get the data from the API. Please try after some time"; //display error message when API not responding
                $scope.isWeatherDisplay = false;
            });

        }
        else {
            alert("Please select the city.")
        }
    };


    //This is the method to get weather report by the default (london) location
    $scope.getDefaultAPIData = function () {

        var strURL = "http://api.openweathermap.org/data/2.5/weather?q=London&appid=8ee69dc69507556267b8f08d4e33f242";
        var post = $http({
            method: "GET",
            url: strURL,
            dataType: 'json',
            headers: { "Content-Type": "application/json" }
        });
        //Success part
        post.then(function (data, status) {
            $scope.Weather = data.data;
            $scope.isWeatherDisplay = true;
        });
        //failure part
        post.error(function (data, status) {
            $scope.isError = true;
            $scope.errorMessage = "Unable to get the data from the default API also. Please try after some time"; //display error message when API not responding
            $scope.isWeatherDisplay = false;
        });
    }


});