﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace IassetTechnicalTest.Controllers
{
    public class WeatherController : ApiController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/Countries")]
        public HttpResponseMessage GetCountries()
        {
            try
            {
                //get all countries data 
                string strCountries = JsonConvert.SerializeObject(WeatherOperations.GetCounties());
                //create httpresponse object with all neccessary data and status of the call
                return Request.CreateResponse(HttpStatusCode.OK, strCountries, Configuration.Formatters.JsonFormatter);
            }
            catch (Exception ex)
            {
                //return error response in case of errors while interacting with the API
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to process the request", Configuration.Formatters.JsonFormatter);
            }
        }

        [HttpGet]
        [Route("api/Cities")]
        public HttpResponseMessage GetCitiesByCountryCode(string code)
        {
            string strCities = "[{'data':'No Data'}]";
            try
            {
                //get all cities data based on the country code              
                List<City> cities = WeatherOperations.GetCities(code);
                if (cities.Count > 0)
                {
                    strCities = JsonConvert.SerializeObject(cities);
                    //create httpresponse object with all neccessary data and status of the call
                    return Request.CreateResponse(HttpStatusCode.OK, strCities, Configuration.Formatters.JsonFormatter);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, strCities, Configuration.Formatters.JsonFormatter);
                }
            }
            catch (Exception ex)
            {
                //return error response in case of errors while interacting with the API
                return Request.CreateResponse(HttpStatusCode.BadRequest, strCities, Configuration.Formatters.JsonFormatter);
            }
        }
    }
    public class Country
    {
        public string Name { get; set; }
        public string Code { get; set; }

        public List<City> Cities { get; set; }
    }

    public class City
    {
        public string CityName { get; set; }

    }

    /// <summary>
    /// This is the class to get all countries and cities details 
    /// </summary>
    public class WeatherOperations
    {
        /// <summary>
        /// This is the method to get countries data
        /// </summary>
        /// <returns>list of countries</returns>
        public static List<Country> GetCounties()
        {
            List<Country> countries = new List<Country>();
            try
            {
                Country obj3 = new Country { Code = "AUS", Name = "Australia", Cities = new List<City>() { new City { CityName = "Sydney" }, new City { CityName = "Melbourne" }, new City { CityName = "Perth" } } };
                Country obj1 = new Country { Code = "IND", Name = "India", Cities = new List<City>() { new City { CityName = "Hyderabad" }, new City { CityName = "Mumbai" }, new City { CityName = "Delhi" } } };
                Country obj2 = new Country { Code = "US", Name = "United Status", Cities = new List<City>() { new City { CityName = "Washington" }, new City { CityName = "Chicago" }, new City { CityName = "Charleston" } } };
                countries.Add(obj1);
                countries.Add(obj2);
                countries.Add(obj3);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return countries;
        }

        /// <summary>
        /// This is the method to get cities data by country code
        /// </summary>
        /// <param name="code">country code to filter the data</param>
        /// <returns>list of cities</returns>
        public static List<City> GetCities(string code)
        {
            try
            {
                //get all countries list
                List<Country> countries = GetCounties();
                //check whether cities are exists or not by country code
                Country country = countries.Where(c => c.Code.ToLower() == code.ToLower()).FirstOrDefault();
                //return cities list
                return (country != null && country.Cities != null) ? country.Cities : (new List<City>());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}